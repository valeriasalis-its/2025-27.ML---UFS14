# Decision Log

## 1. Scelta del progetto: motore scacchistico con deep learning

**Decisione**: Creare un motore scacchistico basato su una CNN per la valutazione delle posizioni.

**Alternative considerate**:
- Classificatore di immagini con transfer learning (più semplice e veloce)
- Sentiment analysis con DistilBERT (meno visivo)
- Classificatore di generi musicali (interessante ma meno profondo tecnicamente)
- Image captioning (troppo complesso per i tempi disponibili)

**Motivazione**: Gli scacchi offrono un dominio ben definito dove il deep learning può dimostrare la capacità di apprendere concetti complessi (struttura posizionale, sicurezza del re, attività dei pezzi) da dati grezzi, senza regole esplicite. Il progetto tocca molti aspetti del ML: preprocessing, architettura CNN, training, valutazione, e integrazione con algoritmi di ricerca classici.

---

## 2. Value network vs Policy network

**Decisione**: Addestrare una value network (valutazione posizioni) anziché una policy network (predizione mosse).

**Alternative considerate**:
- Policy network: predice direttamente la mossa migliore dato uno stato
- Approccio combinato policy + value (stile AlphaZero)

**Motivazione**: Il dataset principale (chessData.csv) conteneva posizioni con valutazioni di Stockfish ma senza la mossa migliore. Solo il dataset tattico (500k posizioni) includeva le mosse. Con 1.5M di posizioni utilizzabili solo per la value network e 416k per la policy, la value network era la scelta più supportata dai dati disponibili. Inoltre la value network è concettualmente più semplice da integrare: basta valutare tutte le posizioni risultanti dalle mosse legali e scegliere la migliore.

---

## 3. Architettura: CNN con blocchi residuali

**Decisione**: Utilizzare una CNN con 8 blocchi residuali e 128 filtri per canale (2.4M parametri).

**Alternative considerate**:
- CNN semplice senza residui (es. stile VGG con MaxPool)
- MLP (Multi-Layer Perceptron) sulla posizione appiattita
- Rete più grande: 12 blocchi, 256 filtri (14M parametri)

**Motivazione**: La scacchiera 8×8 ha struttura spaziale — le relazioni tra pezzi vicini sono fondamentali (un cavallo attacca caselle specifiche, un alfiere controlla diagonali). Le CNN catturano questi pattern spaziali naturalmente con i filtri 3×3. I blocchi residuali con skip connection sono necessari per una rete di 16 layer convoluzionali: senza di essi il gradiente si degraderebbe (vanishing gradient) e i primi layer smetterebbero di imparare. Il MaxPool è stato escluso perché ridurrebbe la risoluzione spaziale — negli scacchi un cavallo in e4 è completamente diverso da un cavallo in a1, e il pooling perderebbe questa distinzione. La rete più grande (14M parametri) è stata testata ma ha mostrato overfitting significativo su 2M dati (train loss 0.035 vs val loss 0.105), confermando che la dimensione scelta era più adeguata al dataset disponibile.

---

## 4. Encoding: tensore 18×8×8

**Decisione**: Rappresentare ogni posizione come un tensore binario di 18 piani 8×8.

**Alternative considerate**:
- Stringa FEN come input testuale
- Matrice 8×8 con un numero per ogni pezzo (es. pedone bianco = 1, cavallo bianco = 2, ecc.)
- Bitboard (12 interi a 64 bit)

**Motivazione**: La rappresentazione a piani binari è lo standard utilizzato da AlphaZero e Leela Chess Zero. Ogni piano codifica la presenza/assenza di un tipo specifico di pezzo, permettendo alla CNN di processare ogni tipo di pezzo in modo indipendente attraverso i canali. I 6 piani extra (turno, arrocco, en passant) aggiungono informazioni cruciali che sono parte integrante della posizione scaccistica — senza di essi due posizioni identiche nei pezzi ma con diritti di arrocco diversi verrebbero valutate allo stesso modo, il che sarebbe scorretto. La matrice con un numero per pezzo comprimerebbe informazioni eterogenee (colore + tipo) in un singolo valore, rendendo più difficile l'apprendimento per la CNN.

---

## 5. Normalizzazione: eval / (|eval| + 300)

**Decisione**: Normalizzare le valutazioni di Stockfish nell'intervallo (-1, +1) con la formula sigmoide `eval / (|eval| + 300)`.

**Alternative considerate**:
- Divisione per il valore massimo (`eval / 10000`)
- StandardScaler di scikit-learn (media 0, varianza 1)
- Clipping a ±1500 e poi divisione lineare

**Motivazione**: La divisione per il massimo comprimerebbe troppo le valutazioni normali (un pedone di vantaggio = +0.01, indistinguibile da posizioni pari). Lo StandardScaler non garantisce un range fisso e le valutazioni estreme (matti) resterebbero enormi. La formula scelta comprime i valori estremi preservando la risoluzione nelle valutazioni medie (±300 centipawns ≈ ±3 pedoni), che è l'intervallo dove si giocano la maggior parte delle partite e dove le differenze contano di più. La costante 300 è stata scelta perché corrisponde approssimativamente al punto dove una posizione passa da "equilibrata" a "chiaramente vinta".

---

## 6. Residual learning: predire Stockfish - materiale

**Decisione**: Addestrare la rete a predire il residuo (valutazione Stockfish - conteggio materiale) anziché la valutazione completa.

**Alternative considerate**:
- Predizione diretta della valutazione di Stockfish (primo approccio implementato)
- Predizione della classe di valutazione (discretizzazione in categorie: perso/svantaggiato/pari/avvantaggiato/vinto)

**Motivazione**: Il primo modello addestrato sulla valutazione diretta mostrava un limite critico: sulla posizione iniziale, la differenza di valutazione con e senza la donna nera era solo +0.101 — la rete faticava a distinguere la perdita della donna in posizioni complesse con molti pezzi. L'intuizione è stata che la rete stava sprecando gran parte della sua capacità (2.4M parametri) per imparare a contare il materiale, un compito matematicamente banale. Sottraendo il conteggio materiale dal target, la rete può concentrarsi esclusivamente sugli aspetti posizionali. Dopo questa modifica la differenza con/senza donna è salita a +0.689 (miglioramento di quasi 7x), e il modello residuale ha vinto 7 partite su 8 contro il modello diretto in un torneo su 8 aperture diverse.

---

## 7. Dimensione del dataset: 2 milioni di posizioni

**Decisione**: Utilizzare 2 milioni di posizioni (1.5M normali + 500k tattiche).

**Alternative considerate**:
- Tutto il dataset disponibile (~15M posizioni)
- Dataset più piccolo (500k) per training più veloce
- Solo posizioni tattiche (500k)

**Motivazione**: Il limite principale era la RAM: 2M posizioni in formato tensore (18×8×8, float32) occupano ~9GB, vicino al limite di Google Colab. Con 4M (18GB) il runtime crashava. 500k sarebbero state troppo poche per una rete da 2.4M parametri — con parametri quasi pari al numero di esempi il rischio di overfitting sarebbe stato elevato. La proporzione 75% normali / 25% tattiche arricchisce il dataset con posizioni dove la tattica è critica (matti, forchette, infilate), che sono sotto-rappresentate nelle partite normali.

---

## 8. Rimozione del Tanh nel modello residuale

**Decisione**: Rimuovere la funzione di attivazione Tanh dall'ultimo layer del value head.

**Alternative considerate**:
- Mantenere il Tanh e rinormalizzare i residui in (-1, +1)
- Usare una funzione di attivazione diversa (es. sigmoid)

**Motivazione**: I residui (Stockfish - materiale) hanno un range che supera (-1, +1), arrivando fino a ±1.85. Il Tanh comprime qualsiasi valore in (-1, +1), rendendo impossibile per la rete predire residui superiori a ±1. Rimuovendo il Tanh l'output è libero e la rete può predire qualsiasi valore. La rinormalizzazione dei residui sarebbe stata possibile ma avrebbe introdotto complessità aggiuntiva senza benefici.

---

## 9. Algoritmo di ricerca: minimax con alpha-beta pruning

**Decisione**: Utilizzare minimax con alpha-beta pruning, move ordering e quiescence search a depth 3.

**Alternative considerate**:
- Solo valutazione della rete senza ricerca (depth 0)
- Monte Carlo Tree Search (MCTS, approccio AlphaZero)
- Minimax senza alpha-beta

**Motivazione**: La sola valutazione della rete (depth 0, o depth 1 valutando tutte le mosse legali) produceva blunder frequenti — la rete non vede le conseguenze delle mosse. MCTS sarebbe stato l'approccio ideale (è quello usato da AlphaZero) ma richiede anche una policy network per guidare l'esplorazione, e i tempi di implementazione non lo permettevano. Minimax con alpha-beta è l'algoritmo classico dei motori scacchistici, ben documentato e relativamente semplice da implementare. L'alpha-beta pruning taglia i rami irrilevanti dell'albero dimezzando il tempo di calcolo. La quiescence search alle foglie evita l'effetto orizzonte: senza di essa il minimax potrebbe fermarsi nel mezzo di una sequenza di catture, valutando una posizione instabile come se fosse definitiva.

---

## 10. Move ordering: MVV-LVA senza controllo scacchi

**Decisione**: Ordinare le mosse con la logica MVV-LVA (Most Valuable Victim - Least Valuable Attacker) senza controllare se una mossa dà scacco.

**Alternative considerate**:
- MVV-LVA con controllo scacchi (implementazione iniziale)
- Nessun ordinamento
- Killer moves heuristic

**Motivazione**: Il controllo scacchi richiedeva `board.push(move)` e `board.pop()` per ogni mossa legale — operazioni molto lente in python-chess (libreria in puro Python). Rimuovendo il controllo scacchi il move ordering è diventato significativamente più veloce, basandosi solo su `board.piece_type_at()` che è un'operazione statica e istantanea. L'impatto sulla qualità dei tagli alpha-beta è minimo perché le catture di pezzi di alto valore sono comunque le mosse più importanti da esplorare per prime.

---

## 11. Quiescence search con valutazione materiale

**Decisione**: Nella quiescence search utilizzare solo il conteggio del materiale anziché la rete neurale.

**Alternative considerate**:
- Quiescence con rete neurale (implementazione iniziale)
- Quiescence con valutazione ibrida

**Motivazione**: La quiescence search esplora solo catture ma può generare migliaia di nodi aggiuntivi. Chiamare la rete neurale per ognuno di questi nodi paralizzava il motore (ogni inferenza PyTorch ha un overhead significativo). Il conteggio del materiale è istantaneo e per le sequenze di catture è sufficiente — durante uno scambio di pezzi ciò che conta è il bilancio materiale, gli aspetti posizionali sono secondari. La rete neurale viene chiamata solo ai nodi foglia del minimax principale (depth 0), dove la valutazione completa (materiale + posizionale) è necessaria.

---

## 12. Piattaforma di training: Colab e Kaggle

**Decisione**: Utilizzare Google Colab e Kaggle Notebooks per il training, VS Code per lo sviluppo del codice.

**Alternative considerate**:
- Training in locale su GPU GTX 1060
- Training in locale su MacBook M2
- Solo Colab
- Solo Kaggle

**Motivazione**: Il PC fisso con GTX 1060 aveva problemi di stabilità e memoria. Il MacBook M2 (di un familiare) avrebbe richiesto setup da zero con tempi stretti. Colab ha il vantaggio dell'integrazione con Google Drive per il salvataggio dei modelli, ma ha limiti sulle ore GPU gratuite. Kaggle offre più ore GPU settimanali (~30h) ma la gestione dei file è meno comoda. La combinazione dei due ha permesso di massimizzare le risorse: Colab per esperimenti rapidi e debug, Kaggle per training lunghi quando le GPU di Colab si esaurivano. VS Code in locale è stato usato per scrivere codice pulito senza consumare risorse cloud.

---

## 13. Transposition table con flag

**Decisione**: Implementare una transposition table con flag EXACT/LOWERBOUND/UPPERBOUND e dimensione limitata.

**Alternative considerate**:
- Nessuna transposition table
- Transposition table senza flag (implementazione iniziale — buggy)
- Transposition table illimitata

**Motivazione**: Senza transposition table il minimax ricalcola posizioni già incontrate, perdendo tempo. La prima implementazione salvava i valori senza flag, ma l'alpha-beta pruning restituisce spesso limiti (superiori o inferiori) anziché valori esatti — trattare un limite come valore esatto causa errori nelle valutazioni. I flag distinguono il tipo di valore salvato e permettono di usarlo correttamente. Il limite di 500k entry evita che la tabella cresca indefinitamente durante partite lunghe, esaurendo la RAM.
