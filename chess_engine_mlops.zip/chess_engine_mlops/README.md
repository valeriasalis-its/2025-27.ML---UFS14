# Motore Scacchistico con Deep Learning

## Setup/How to run this project

### Requisiti di sistema
- Python 3.14
- GPU consigliata per il training (NVIDIA T4 o superiore), CPU sufficiente per il gioco
- ~10GB di RAM per il preprocessing del dataset
- ~2GB di spazio disco per il dataset preprocessato

### Librerie necessarie
```bash
pip install torch torchvision numpy pandas python-chess tqdm
```

### Come far partire il progetto

**1. Training (richiede GPU):**
Aprire il notebook `chess_engine.ipynb` su Google Colab o Kaggle con GPU attiva ed eseguire tutte le celle in ordine. Il training richiede circa 1.5 ore su GPU T4.

I dataset necessari (`chessData.csv` e `tactic_evals.csv`) sono disponibili su Kaggle e vanno posizionati nella stessa cartella del notebook.

**2. Utilizzo del modello pre-addestrato:**
Se si dispone già del file `best_model_residual.pt`, è possibile saltare le celle di preprocessing e training e caricare direttamente il modello dalla cella 9 in poi.

**3. Far giocare il motore:**
Dopo aver caricato il modello, eseguire le celle del motore (minimax + alpha-beta) e utilizzare la funzione `my_move("e2e4")` per giocare contro il modello in notazione UCI.

**4. Torneo tra modelli:**
Eseguire `torneo.py` nella stessa cartella dei file `.pt` dei modelli:
```bash
python torneo.py
```
Le partite vengono salvate in formato PGN nella cartella `partite/`, importabili su lichess.org/paste.

## Spiegazione del progetto

L'obiettivo è creare un motore scacchistico la cui funzione di valutazione delle posizioni è basata su una rete neurale convoluzionale (CNN), anziché su regole scritte a mano come nei motori tradizionali.

Il motore tradizionale (es. Stockfish prima di NNUE) utilizza centinaia di regole hardcoded per valutare una posizione: valore dei pezzi, tabelle posizionali, struttura pedonale, sicurezza del re, ecc. Il nostro approccio sostituisce tutto questo con una CNN addestrata su 2 milioni di posizioni valutate da Stockfish, che impara autonomamente a riconoscere i pattern posizionali dalla scacchiera.

L'idea chiave del progetto è il **residual learning**: invece di predire la valutazione completa di Stockfish, la rete predice solo la differenza tra la valutazione di Stockfish e il semplice conteggio del materiale. Questo permette alla rete di concentrare tutta la sua capacità sugli aspetti posizionali (re esposto, struttura pedonale, attività dei pezzi) senza sprecare parametri per imparare a contare i pezzi.

Per far giocare il modello, la valutazione della rete viene integrata in un algoritmo di ricerca minimax con alpha-beta pruning, move ordering (MVV-LVA) e quiescence search, che esplora l'albero delle mosse fino a 3-4 livelli di profondità.

## Dati

### Fonti
Due dataset pubblici da Kaggle, entrambi contenenti posizioni scacchistiche in formato FEN con valutazioni di Stockfish in centipawns:

- **chessData.csv** (~15 milioni di posizioni): posizioni estratte da partite reali giocate su Lichess
- **tactic_evals.csv** (~2 milioni di posizioni): posizioni con pattern tattici marcati (matti, forchette, infilate)

### Campionamento
Dal primo dataset sono state campionate casualmente 1.5 milioni di posizioni, dal secondo 500k, per un totale di 2 milioni. La proporzione 75%/25% garantisce che il dataset contenga sia posizioni di gioco normale sia posizioni tatticamente ricche.

### Caratteristiche dei dati
Ogni riga contiene:
- **FEN**: stringa che rappresenta la posizione completa della scacchiera (posizione pezzi, turno, diritti di arrocco, en passant)
- **Evaluation**: valutazione di Stockfish in centipawns (es. "+490") o notazione di matto (es. "#+3")

### Gestione dati problematici
- **Valutazioni di matto** (es. "#+3", "#-1"): convertite in ±10000 centipawns
- **Colonna Move nel dataset tattico**: rimossa in quanto il modello predice solo la valutazione, non la mossa
- **Normalizzazione**: tutte le valutazioni sono normalizzate nell'intervallo (-1, +1) con la formula `eval / (|eval| + 300)`, che comprime i valori estremi preservando la risoluzione nelle valutazioni medie dove si giocano la maggior parte delle partite

### Encoding
Ogni posizione FEN viene convertita in un tensore di dimensione (18, 8, 8):
- 12 piani binari per i pezzi (6 tipi × 2 colori)
- 1 piano per il turno
- 4 piani per i diritti di arrocco
- 1 piano per la casella en passant

Questa rappresentazione è analoga a un'immagine con 18 canali, dove ogni canale codifica un aspetto della posizione.

## Ciclo di vita ML

### Raccolta dati
I dati provengono da dataset pubblici su Kaggle, originariamente generati dalla piattaforma Lichess con valutazioni calcolate da Stockfish a profondità elevata. La raccolta è stata una tantum: download dei CSV e campionamento casuale.

### Training
Il training è stato effettuato su GPU (NVIDIA T4 su Google Colab e Kaggle) per 15 epoche con optimizer Adam (lr=0.001) e scheduler ReduceLROnPlateau. Il dataset è stato diviso 90% training / 10% validazione. Il modello migliore viene salvato automaticamente in base alla validation loss.

### Validazione
La validazione avviene su 200k posizioni mai viste durante il training. Oltre alla loss numerica (MSE), il modello è stato testato qualitativamente su:
- Posizioni con vantaggio materiale noto (donna, torre, alfiere, ecc.)
- Confronto diretto con le valutazioni di Stockfish su posizioni specifiche
- Torneo tra il modello residuale e il modello con valutazione diretta (7 vittorie su 8)

### Deploy
Il deploy attuale è locale: il modello gira come script Python o notebook Jupyter. Un possibile deploy futuro potrebbe essere un bot su Lichess tramite il protocollo UCI e le API di Lichess.

### Monitoring
In un contesto di deploy continuo si monitorerebbe:
- La correlazione tra le valutazioni del modello e quelle di Stockfish su posizioni nuove
- L'ELO stimato del motore su piattaforme online
- Il tempo medio per mossa

## MLOps

### Monitoraggio
- **Val loss durante il training**: indicatore primario di overfitting
- **Qualità delle valutazioni**: confronto periodico con Stockfish su un set di posizioni benchmark
- **Performance del motore**: ELO stimato tramite partite contro altri motori

### Re-training
Il re-training sarebbe necessario se:
- Venissero disponibili dataset più grandi o di qualità superiore (es. valutazioni di Stockfish a profondità maggiore)
- Si cambiasse l'architettura della rete (più blocchi, più filtri)
- Si volesse adattare il modello a varianti specifiche degli scacchi (es. Chess960)
- La distribuzione delle posizioni incontrate in partite reali divergesse significativamente da quella del training set

## Rischi, assunzioni e limiti

### Limiti identificati
- **Endgame debole**: il modello non riesce a dare scacco matto con pochi pezzi (es. re + donna vs re). Questo richiede sequenze precise di 15-20 mosse che la profondità di ricerca limitata non riesce a pianificare
- **Promozione inconsistente**: il motore non sempre promuove i pedoni in modo efficace
- **Valutazione imprecisa in posizioni tattiche complesse**: la rete a volte sovrastima il valore degli scacchi, sacrificando materiale per dare scacco senza beneficio reale
- **Velocità**: a depth 3 il motore impiega 10-120 secondi per mossa su GPU, principalmente a causa del loop Python nel minimax
- **Bias del bianco**: la rete assegna un leggero vantaggio al bianco (+0.2) anche in posizioni perfettamente pari, probabilmente perché nel dataset il bianco vince più spesso (53-54%)

### Assunzioni
- Le valutazioni di Stockfish nel dataset sono corrette e rappresentative della vera forza delle posizioni
- 2 milioni di posizioni sono sufficienti per addestrare una rete da 2.4M parametri (confermato empiricamente dall'assenza di overfitting grave)
- Il conteggio del materiale con i valori classici (P=1, C=3, A=3, T=5, D=9) è una buona approssimazione della componente materiale della valutazione

### Ampliamenti possibili
Il progetto è funzionante dall'inizio alla fine. Possibili ampliamenti:
- **Più dati** (4-8M posizioni) per una rete più grande senza overfitting
- **Rete più grande** (12 blocchi, 256 filtri = 14M parametri) — testata ma con overfitting su 2M dati
- **Monte Carlo Tree Search (MCTS)** al posto del minimax — approccio di AlphaZero, permette di gestire meglio il tempo di ricerca
- **Policy network** aggiuntiva per guidare la ricerca dell'albero
- **Deploy come bot su Lichess** per testare l'ELO reale contro giocatori umani e altri BOT
- **Riscrittura del motore in C++** per eliminare il bottleneck della lentezza di esecuzione di python

## Ulteriori informazioni

### Confronto tra modello diretto e residuale
Il progetto ha sviluppato due versioni del modello:
1. **Modello diretto**: la rete predice la valutazione completa di Stockfish. Test della differenza con/senza donna nera sulla posizione iniziale: +0.101 (la rete non distingue bene la perdita della donna)
2. **Modello residuale**: la rete predice solo la differenza rispetto al conteggio materiale. Stessa test: +0.689 (miglioramento di quasi 7x)

Il modello residuale ha vinto 7 partite su 8 in un torneo diretto contro il modello con valutazione diretta, confermando il vantaggio dell'approccio.

### Strumenti utilizzati
- **PyTorch**: framework per il deep learning
- **python-chess**: gestione delle regole scacchistiche, generazione mosse legali, formato PGN
- **Google Colab / Kaggle**: GPU per il training
- **Lichess**: visualizzazione delle partite tramite import PGN

### Ispirazione
L'architettura è ispirata a quella di AlphaZero (DeepMind), adattata alle risorse disponibili: dove AlphaZero utilizza 40 blocchi residuali, 256 filtri e self-play su migliaia di TPU, il nostro modello usa 8 blocchi, 128 filtri e supervised learning su una singola GPU consumer.
